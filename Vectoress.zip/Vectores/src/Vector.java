public class Vector {
    int[] vectorA = {3,3};
    int [] vectorB = {1,4};
    int [] vectorC = {4,7};

    int [] vectorU = {3,3,2};

    int [] vectorV = {1,4,4};

    int [] vectorW = {4,7,5};

    int [] vectorC2 = {4,3,-5};

    public int[] getVectorU() {
        return vectorU;
    }

    public void setVectorU(int[] vectorU) {
        this.vectorU = vectorU;
    }

    public int[] getVectorV() {
        return vectorV;
    }

    public void setVectorV(int[] vectorV) {
        this.vectorV = vectorV;
    }

    public int[] getVectorW() {
        return vectorW;
    }

    public void setVectorW(int[] vectorW) {
        this.vectorW = vectorW;
    }

    public int[] getVectorC2() {
        return vectorC2;
    }

    public void setVectorC2(int[] vectorC2) {
        this.vectorC2 = vectorC2;
    }

    public int[] getVectorA() {
        return vectorA;
    }

    public void setVectorA(int[] vectorA) {
        this.vectorA = vectorA;
    }

    public int[] getVectorB() {
        return vectorB;
    }

    public void setVectorB(int[] vectorB) {
        this.vectorB = vectorB;
    }

    public int[] getVectorC() {
        return vectorC;
    }

    public void setVectorC(int[] vectorC) {
        this.vectorC = vectorC;
    }
}
