import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        Operationsr2 op = new Operationsr2();
        Vector vector = new Vector();
        Scalar scalar = new Scalar();
        System.out.println("R2 OPERATIONS: ");
        System.out.println("Suma: ");
        System.out.println(Arrays.toString(new String[]{Arrays.toString(vector.vectorA) + " + " +Arrays.toString(vector.vectorB) }));
        op.VectorSum(vector.getVectorA(), vector.getVectorB());
        //Resta de vectoes
        System.out.println("Resta: ");
        System.out.println(Arrays.toString(new String[]{Arrays.toString(vector.vectorA) + " - " +Arrays.toString(vector.vectorB) }));
        op.VectoRes(vector.getVectorA(), vector.getVectorB());
        //Suma 7(A+C)
        System.out.println("Scalar Multiply");
        System.out.println("(" + Arrays.toString(new String[]{Arrays.toString(vector.vectorA) + " + " +Arrays.toString(vector.vectorC) }) + ") * 7");
        op.multiplyScalar(vector.getVectorA(), vector.getVectorC(), scalar.escalar);
        //SumaDos 7(A+B)-C
        System.out.println("Scalar Multiply v2");
        System.out.println("( (" + Arrays.toString(new String[]{Arrays.toString(vector.vectorA) + " + " +Arrays.toString(vector.vectorB) }) + ") * 7 )" + " - " +Arrays.toString(vector.vectorC) );
        op.multiplyScalarAndC(vector.vectorA, vector.vectorB, vector.vectorC, scalar.escalar);
        //Magnitud de r2
        System.out.println("Magnitud r2");
       op.magnitudr2(vector.vectorA, vector.vectorB, vector.vectorC);
       //Magnitud de r3
        System.out.println("Magnitud r3");
        op.magnitudr3(vector.vectorU, vector.vectorV, vector.vectorW,vector.vectorC2);
    }





}
