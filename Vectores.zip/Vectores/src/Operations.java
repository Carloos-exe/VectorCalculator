import java.util.Arrays;

public class Operations {
    public void VectorSum(int Vector[], int Vector2[] ){
        int[] vectorRes = new int[Vector.length];
        if (Vector.length!=Vector2.length){
            System.out.println("Invalid");
        }
        else if (Vector.length==Vector2.length){
            for (int i = 0; i < Vector.length; i++) {
                vectorRes[i] = Vector[i] + Vector2[i];
            }

        }
        System.out.println(Arrays.toString(vectorRes));

    }
    public void VectoRes(int Vector[], int Vector2[] ){
        int[] vectorRes = new int[Vector.length];
        if (Vector.length!=Vector2.length){
            System.out.println("Invalid");
        }
        else if (Vector.length==Vector2.length){
            for (int i = 0; i < Vector.length; i++) {
                vectorRes[i] = Vector[i] - Vector2[i];
            }

        }
        System.out.println(Arrays.toString(vectorRes));

    }

    public void multiplyScalar(int Vector[], int Vector2[], int escalar ){
        int[] vectorRes = new int[Vector.length];
        if (Vector.length!=Vector2.length){
            System.out.println("Invalid");
        }
        else if (Vector.length==Vector2.length){
            for (int i = 0; i < Vector.length; i++) {
                vectorRes[i] = Vector[i] + Vector2[i];
            }
            for (int i = 0; i < vectorRes.length; i++) {
                vectorRes[i] = vectorRes[i] * escalar;
            }
        }
            System.out.println(Arrays.toString(vectorRes));

    }

    public void multiplyScalarAndC(int Vector[], int Vector2[], int Vector3[], int escalar ) {
        int[] vectorRes = new int[Vector.length];
        if (Vector.length != Vector2.length) {
            System.out.println("Invalid");
        } else if (Vector.length == Vector2.length) {
            for (int i = 0; i < Vector.length; i++) {
                vectorRes[i] = Vector[i] + Vector2[i];
            }
            for (int i = 0; i < vectorRes.length; i++) {
                vectorRes[i] = vectorRes[i] * escalar;
            }
            for (int i = 0; i < Vector.length; i++) {
                vectorRes[i] = vectorRes[i] -  Vector3[i];

            }
            System.out.println(Arrays.toString(vectorRes));

        }


    }

}
