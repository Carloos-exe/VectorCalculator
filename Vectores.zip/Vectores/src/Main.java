import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        Operations op = new Operations();
        Vector v = new Vector();
        System.out.println("R2 OPERATIONS: ");
        System.out.println("Suma: ");
        System.out.println(Arrays.toString(new String[]{Arrays.toString(v.vectorA) + " + " +Arrays.toString(v.vectorB) }));
        System.out.println("=");
        op.VectorSum(v.getVectorA(), v.getVectorB());
        //Resta de vectoes
        System.out.println("Resta: ");
        System.out.println(Arrays.toString(new String[]{Arrays.toString(v.vectorA) + " - " +Arrays.toString(v.vectorB) }));
        System.out.println(" = ");
        op.VectoRes(v.getVectorA(), v.getVectorB());
        //Suma 7(A+C)
        System.out.println("Scalar Multiply");
        System.out.println("(" + Arrays.toString(new String[]{Arrays.toString(v.vectorA) + " + " +Arrays.toString(v.vectorC) }) + ") * 7");
        System.out.println(" = ");
        op.multiplyScalar(v.getVectorA(), v.getVectorC(),v.escalar);
        //SumaDos
        System.out.println("Scalar Multiply v2");
        System.out.println("( (" + Arrays.toString(new String[]{Arrays.toString(v.vectorA) + " + " +Arrays.toString(v.vectorB) }) + ") * 7 )" + " - " +Arrays.toString(v.vectorC) );
        System.out.println(" = ");
        op.multiplyScalarAndC(v.vectorA,v.vectorB,v.vectorC,v.escalar);




    }





}
