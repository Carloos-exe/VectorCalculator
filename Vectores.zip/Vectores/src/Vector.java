public class Vector {
    int[] vectorA = {3,3};
    int [] vectorB = {1,4};
    int [] vectorC = {4,7};

    int escalar = 7;

    public int getEscalar() {
        return escalar;
    }

    public void setEscalar(int escalar) {
        this.escalar = escalar;
    }

    public int[] getVectorA() {
        return vectorA;
    }

    public void setVectorA(int[] vectorA) {
        this.vectorA = vectorA;
    }

    public int[] getVectorB() {
        return vectorB;
    }

    public void setVectorB(int[] vectorB) {
        this.vectorB = vectorB;
    }

    public int[] getVectorC() {
        return vectorC;
    }

    public void setVectorC(int[] vectorC) {
        this.vectorC = vectorC;
    }
}
